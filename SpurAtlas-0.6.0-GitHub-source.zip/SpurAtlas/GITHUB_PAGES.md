# SpurAtlas on GitHub Pages

This directory prepares the existing SpurAtlas 0.6.0 release for GitHub Pages.
The six website pages, styling, calculations, retained evidence, downloadable
geometry and research software are copied from the published release. Their
source identities are recorded in GITHUB_PAGES_PROVENANCE.json.

The .github/workflows/pages.yml workflow runs the software checks before
publishing dist/. It uses GitHub Pages artifact deployment; no Jekyll build,
external JavaScript dependency or finite-element solution is required.

## Publish

Create a public GitHub repository named SpurAtlas under the verified account.
Push this directory to its main branch. In Settings > Pages, choose GitHub
Actions as the build and deployment source. Run the Publish SpurAtlas to
GitHub Pages workflow, then use the verified deployment URL from that run.
The relative website links support a project subdirectory.

The existing hosted Atlas remains available during this transfer. Its source
repository and public access have not been changed by preparing this copy.
After GitHub provides the actual website URL, update the website URL in both
CITATION.cff files and the download link in the standalone printable report.
Regenerate the calculation reproduction ZIP and run the software checks again
if those included files change. Keep all scientific inputs and equations fixed.

## Citation and scope

Software archive: https://doi.org/10.5281/zenodo.24165269
Supporting numerical release: https://doi.org/10.5281/zenodo.24144925
Original benchmark: https://doi.org/10.5281/zenodo.24055230

The existing README.md describes numerical scope and reproduction. The Atlas
supports retained research comparisons and declared manufacturing scenarios;
GitHub publication does not add physical validation or production qualification.
Software: MIT. Research data: CC BY 4.0. Third-party rights are retained.
