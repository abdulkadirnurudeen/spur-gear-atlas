# SpurAtlas 0.6.0 — reproducible design calculation

Unzip this package into a new folder. Node.js 20 or newer is required; there
are no external JavaScript dependencies. The browser and this replay use the
same retained data and pure calculation module.

Run the example:

    node reproduce.mjs example-request.json recalculated.json --html report.html

Replay a JSON calculation exported from the website:

    node reproduce.mjs exported_calculation.json recalculated.json --html report.html

Open report.html in a browser and print it or save it as a PDF. Its selected
field figure is embedded in the file. JSON numerical results reproduce;
generatedUtc records the new replay time. The original exported project label
is retained locally. Verify that requirements, selected case and carbon inputs
match before comparing outputs.

Run all software checks:

    node --test tests/*.test.js

The SHA-256 manifest detects changed package bytes; it is not a digital
signature or independent engineering certification. The script verifies the
manifest before executing the calculation modules.

The ten case figures are recovered from SHA-256-authenticated mesh and nodal
displacement arrays. tools/render_case_fields.py records how to recover them
from the separately archived raw files. Their regional stress maxima reproduce
the retained assessment to the tolerance recorded in data/field-recovery.json.
The large raw arrays are not duplicated in this small replay package. No new
FE solve occurs. tools/build_engineering.py rebuilds metadata and drawings from
the complete retained numerical/document source package.

Scope: compatible retained 42/46-tooth cases, 200 mm pitch diameter, 30 mm face
and bore, 20-degree pressure angle, five saved force/body-load mixtures and
five million counted fatigue cycles. Wider tooth counts are research-index
records and do not acquire missing absolute factors through this tool.
Homogeneous material comparisons preserve the declared density and Poisson
ratio. Published specimen fits are not production allowables. Conditional
error bands are sensitivity assumptions, not calibrated physical uncertainty.

Matched climate results are new same-geometry route-planning scenarios from
the archived route equation. Default milling uses the retained geometry-specific roughing and finishing
recipe, with its cutter references, operation fractions and electricity inventory.
Miles are displayed; canonical source units are retained for exact replay. Real
tool reach, machine stability, material state, fatigue performance, measured
inventory, ISO 6336 gear ratings and full LCA conformity remain separate
assessments. Each report records their status explicitly.

Author: Abdulkadir Oshioze Nurudeen; ORCID 0000-0002-2646-5784.
Supporting numerical data: https://doi.org/10.5281/zenodo.24144925 (2.0.0).
Original benchmark: https://doi.org/10.5281/zenodo.24055230.
Software: MIT. Research data: CC BY 4.0; third-party rights remain with owners.
