import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root=new URL('./',import.meta.url);
const read=p=>JSON.parse(readFileSync(new URL(p,root),'utf8'));
const manifest=read('manifest.json');
for(const [path,hash]of Object.entries(manifest.files)){const actual=createHash('sha256').update(readFileSync(new URL(path,root))).digest('hex');if(actual!==hash)throw new Error('Integrity mismatch: '+path);}
const {shortlist,makeReport,carbonDefaults}=await import('./dist/design-model.js');
const {printable}=await import('./dist/design-ui.js');
const data=read('dist/data/atlas.json'),engineering=read('dist/data/engineering.json');
const input=JSON.parse(readFileSync(process.argv[2]||new URL('example-request.json',root),'utf8'));
const request=input.requirements||input;const result=shortlist(data,request);
const selected=input.selection?.id||input.selectedId||result.recommended||result.rows[0]?.id;
const report=makeReport(data,engineering,request,result,selected,input.carbonSettings||carbonDefaults,input.project||'');
const text=JSON.stringify(report,null,2)+'\n';if(process.argv[3])writeFileSync(process.argv[3],text);else process.stdout.write(text);
const html=process.argv.indexOf('--html');if(html>=0&&process.argv[html+1]){const field=engineering.cases[selected]?.fieldPlot;const imageData=field?'data:image/png;base64,'+readFileSync(new URL('dist/'+field.image,root)).toString('base64'):'';writeFileSync(process.argv[html+1],printable(report,data,engineering,imageData));}
